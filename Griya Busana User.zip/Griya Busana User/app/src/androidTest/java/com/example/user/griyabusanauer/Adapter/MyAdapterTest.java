package com.example.user.griyabusanauer.Adapter;

import static org.junit.Assert.*;

public class MyAdapterTest {

}