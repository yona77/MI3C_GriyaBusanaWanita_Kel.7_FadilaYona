package com.example.user.griyabusanauer;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.telecom.Call;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.user.griyabusanauer.Adapter.BajuAdapter;
import com.example.user.griyabusanauer.Model.Baju;
import com.example.user.griyabusanauer.Model.GetBaju;
import com.example.user.griyabusanauer.Rest.ApiClient;
import com.example.user.griyabusanauer.Rest.ApiInterface;
import com.example.user.griyabusanauer.Adapter.BajuAdapter;
import com.example.user.griyabusanauer.Model.GetBaju;
import com.example.user.griyabusanauer.Model.Baju;
import com.example.user.griyabusanauer.Rest.ApiClient;
import com.example.user.griyabusanauer.Rest.ApiInterface;

import java.util.List;

import javax.security.auth.callback.Callback;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LayarListBaju extends AppCompatActivity {

    RecyclerView mRecyclerView;
    RecyclerView.Adapter mAdapter;
    RecyclerView.LayoutManager mLayoutManager;
    Context mContext;
    ApiInterface mApiInterface;
//    Button btGet, btAddData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_layar_list_baju);

        mContext = getApplicationContext();
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        mLayoutManager = new LinearLayoutManager(mContext);
        mRecyclerView.setLayoutManager(mLayoutManager);
        //btGet = (Button) findViewById(R.id.btGet);
//        btAddData = (Button) findViewById(R.id.btAddData);
//
//        btGet.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                mApiInterface = ApiClient.getClient().create(ApiInterface.class);
//                Call<GetBaju> mPBajuCall = mApiInterface.getPembeli();
//                mPembeliCall.enqueue(new Callback<GetPembeli>() {
//
//                    @Override
//                    public void onResponse(Call<GetPembeli> call, Response<GetPembeli> response) {
//                        Log.d("Get Pembeli",response.body().getStatus());
//                        List<Pembeli> listPembeli = response.body().getResult();
//                        mAdapter = new PembeliAdapter(listPembeli);
//                        mRecyclerView.setAdapter(mAdapter);
//                    }
//
//                    @Override
//                    public void onFailure(Call<GetPembeli> call, Throwable t) {
//                        Log.d("Get Pembeli",t.getMessage());
//                    }
//                });
//            }
//        });
//
//        btAddData.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(mContext, LayarInsertPembeli.class);
//                startActivity(intent);
//            }
//        });
       getData();
 }
    private void getData() {
        mApiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<GetBaju> mBajuCall = mApiInterface.getBaju();
        mBajuCall.enqueue(new Callback<GetBaju>() {
            @Override
            public void onResponse(retrofit2.Call<GetBaju> call, Response<GetBaju> response) {
                Log.d("GetBaju",String.valueOf(response.body().getResult())));
                List<Baju> listBaju = response.body().getResult();
                mAdapter = new BajuAdapter(listBaju, LayarListBaju.this);
                mRecyclerView.setAdapter(mAdapter);
            }

            @Override
            public void onFailure(retrofit2.Call<GetBaju> call, Throwable t) {
                Log.d("Get Baju",t.getMessage());
            }
        });

}

}
