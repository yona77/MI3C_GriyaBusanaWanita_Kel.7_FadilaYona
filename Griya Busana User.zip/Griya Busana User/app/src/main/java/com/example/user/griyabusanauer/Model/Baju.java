package com.example.user.griyabusanauer.Model;

public class Baju {


    private String idBaju;

    private String namaBaju;

    private String harga;

    private String deskripsi;

    private String photoUrl;
    private String action;

    public Baju (String idBaju, String namaBaju, String harga, String deskripsi, String photoUrl, String action) {
        this.idBaju = idBaju;
        this.namaBaju      = namaBaju;
        this.harga    = harga;
        this.deskripsi      = deskripsi;
        this.photoUrl  = photoUrl;
        this.action    = action;
    }

    public String getIdBaju() {
        return idBaju;
    }
    public void setIdBaju(String idPembeli) {
        this.idBaju = idPembeli;
    }

    public String getNamaBaju() {
        return namaBaju;
    }
    public void setNamaBaju(String namaBaju) {
        this.namaBaju = namaBaju;
    }

    public String getHarga() {
        return harga;
    }
    public void setHarga(String hargaarga) {
        this.harga= harga;
    }

    public String getDeskripsi() {
        return deskripsi;
    }
    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }
    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }

    public String getAction() {
        return action;
    }
    public void setAction(String action) {
        this.action = action;
    }
}

