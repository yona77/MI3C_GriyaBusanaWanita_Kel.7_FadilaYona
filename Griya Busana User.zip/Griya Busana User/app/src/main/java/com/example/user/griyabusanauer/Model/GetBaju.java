package com.example.user.griyabusanauer.Model;

import java.util.ArrayList;
import java.util.List;

public class GetBaju {
    @SerializedName("status")
    private String status;
    @SerializedName("result")
    private List<Baju> result = new ArrayList<>();

/private String message;


    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public List<Baju> getResult() {
        return result;
    }
    public void setResult(List<Baju> result) {
        this.result = result;
    }

    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
}

