package com.example.user.griyabusanauer.Adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.user.griyabusanauer.Model.Baju;
import com.example.user.griyabusanauer.R;
import com.example.user.griyabusanauer.Rest.ApiInterface;

import java.util.List;

public class BajuAdapter extends RecyclerView.Adapter<BajuAdapter.BajuViewHolder> {
    List<Baju> listBaju;
    Context mContext;
    ApiInterface mApiInterface;

    public BajuAdapter(List<Baju> listBaju) {
        this.listBaju = listBaju;
    }
    this.listBaju = listBaju;
    this.mContext = mContex;

//    @Override
//    public BajuAdapter.BajuViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_baju, parent, false);
//        BajuViewHolder mHolder = new BajuViewHolder(view);
//        return mHolder;
//    }
@Override
public BajuViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
    View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_baju, parent, false);
    BajuViewHolder mHolder = new BajuViewHolder(view);
    return mHolder;
}

    @Override
    public void onBindViewHolder(BajuAdapter.BajuViewHolder holder, final int position) {

        holder.tvIdBaju.setText(listBaju.get(position).getIdBaju());
        holder.tvNamaBaju.setText(listBaju.get(position).getNamaBaju());
        holder.tvHarga.setText(listBaju.get(position).getHarga());
        holder.tvDeskripsi.setText(listBaju.get(position).getDeskripsi());
        if (listBaju.get(position).getPhotoUrl() != null ){

            Glide.with(holder.itemView.getContext()).load(listBaju.get
                    (position).getPhotoUrl())
                    .into(holder.mPhotoURL);
        } else {
//            Picasso.with((holder.itemView.getContext().load))
//            imageViewFavorite.setImageResource(
//                    listLaptop.get(position).getIsFavorite()? R.drawable.ic_favorite : R.drawable.ic_not_favorite);
//            return;

    Glide.with(holder.itemView.getContext()).load(R.drawable.yona).into(holder.mPhotoURL);
        }
    }

//        holder.itemView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(v.getContext(), LayarEditBaju.class);
//                intent.putExtra("id_baju", listBaju.get(position).getIdBaju());
//                intent.putExtra("namaBaju", listBaju.get(position).getNamaBaju());
//                intent.putExtra("harga", listBaju.get(position).getHarga());
//                intent.putExtra("deskripsi", listBaju.get(position).getDeskripsi());
//                intent.putExtra("photo_url", listBaju.get(position).getPhotoUrl());
//                v.getContext().startActivity(intent);
//            }
//        });
//    }

    @Override
    public int getItemCount() {
        return listBaju.size();
    }

    public class BajuViewHolder extends RecyclerView.ViewHolder {
        ImageView mPhotoURL;
        TextView tvIdBaju, tvNamaBaju, tvHarga, tvDeskripsi;


        public BajuViewHolder(View itemView) {
            super(itemView);
            mPhotoURL = (ImageView) itemView.findViewById(R.id.imgBaju);
            tvIdBaju = (TextView) itemView.findViewById(R.id.tvIdBaju);
            tvNamaBaju = (TextView) itemView.findViewById(R.id.tvNamaBaju);
            tvHarga = (TextView) itemView.findViewById(R.id.tvHargaContent);
            tvDeskripsi = (TextView) itemView.findViewById(R.id.tvDeskripsiContent);
        }
    }
}

