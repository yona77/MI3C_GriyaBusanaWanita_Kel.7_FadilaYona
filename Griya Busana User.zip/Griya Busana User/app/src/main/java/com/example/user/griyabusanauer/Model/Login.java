package com.example.user.griyabusanauer.Model;

import com.google.gson.annotations.SerializedName;

public class Login {
    @SerializedName("id_pembeli")
    private String id_pembeli;

    public String getId_pembeli() {
        return id_pembeli;
    }

    public void setId_pembeli (String id_pembeli) {
        this.id_pembeli = id_pembeli;
    }
}
}
